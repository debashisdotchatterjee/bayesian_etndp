# Bayesian ETNDP engineered simulation package

Run in Colab:

```python
%run bayesian_etndp_engineered_simulation.py
```

Fast run:

```python
from bayesian_etndp_engineered_simulation import SimulationConfig, run_full_simulation
cfg = SimulationConfig(posterior_scenarios=30, future_scenarios=40, show_plots=True, show_tables=True)
results = run_full_simulation(cfg)
```

The script implements manual Bayesian updating, posterior predictive scenarios, seven topology classes, posterior CVaR, chance-constraint reliability, deterministic baseline comparison, future stress-test validation, plots, CSV tables, and an output ZIP.
