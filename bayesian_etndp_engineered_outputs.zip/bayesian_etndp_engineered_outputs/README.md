# Bayesian ETNDP engineered simulation outputs

This folder was created by `bayesian_etndp_engineered_simulation.py`.

The simulation intentionally creates a logistics setting where uncertainty matters:
OD demand has sale/surge days, travel times have storm/disruption regimes, and hub
sorting reliability is uncertain.  The deterministic mean-only baseline ignores
posterior tail risk and reliability chance constraints, whereas the Bayesian method
uses posterior expected cost, CVaR of maximum arrival time, and reliability penalties.

Selected Bayesian design: DSAHS|H=4-8-3|cap=1.85|direct=0.12
Selected deterministic baseline: DSAHS|H=4-8-3|cap=1.05|direct=0.12

Main files:
- tables/posterior_design_summary_all.csv
- tables/best_design_by_topology.csv
- tables/bayesian_vs_deterministic_selected_designs.csv
- tables/future_stress_test_summary.csv
- tables/bayesian_verification_gains.csv
- figures/03_posterior_tradeoff_cost_cvar.png
- figures/08_future_bayes_vs_deterministic_arrival.png
